package com.example.avani;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(this, MainActivity3.class);
        Toast.makeText(getApplicationContext(),"onCreate invoked",Toast.LENGTH_LONG).show();
        Log.d("lifecycle","onCreate invoked") ;
        EditText num1 , num2 ;
        Button sum ;
        TextView res ;
        num1 = findViewById(R.id.n1) ;
        num2 = findViewById(R.id.n2) ;
        sum = findViewById(R.id.button);
        res = findViewById(R.id.result) ;
        sum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n1 = Integer.parseInt(num1.getText().toString()) ;
                int n2 = Integer.parseInt(num2.getText().toString()) ;
                int s = n1+n2 ;
                res.setText("SUM is : " +s);
                Bundle extras=new Bundle();
                extras.putString("num1",n1+"");
                extras.putString("num2",n2+"");
                extras.putString("sum",s+"");
                intent.putExtras(extras);
                startActivity(intent);


            }
        });
    }
    protected void onStart(){
        super.onStart();
        Log.d("lifecycle","onStartInvoked") ;
    }
    protected void onResume(){
        super.onResume();
        Log.d("lifecycle","onResumeInvoked") ;
    }
    protected void onPause(){
        super.onPause();
        Log.d("lifecycle","onPauseInvoked") ;
    }
    protected void onStop(){
        super.onStop();
        Log.d("lifecycle","onStopInvoked") ;
    }
    protected void onRestart(){
        super.onRestart();
        Log.d("lifecycle","onRestartInvoked") ;
    }
    protected void onDestroy(){
        super.onDestroy();
        Log.d("lifecycle","onDestroyInvoked") ;
    }
}